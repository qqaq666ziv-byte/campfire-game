const { createApp, ref, computed, onMounted, watch } = Vue;

// 🎵 音效系統：預先載入背景音樂與點擊/升級音效
const bgm = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3');
bgm.loop = true; bgm.volume = 0.2; // 背景音樂無限循環，音量調小
const hitSound = new Audio('https://actions.google.com/sounds/v1/impacts/wood_hit_metal.ogg');
const levelUpSound = new Audio('https://actions.google.com/sounds/v1/cartoon/cartoon_cowbell.ogg');

createApp({
  setup() {
    // ==========================================
    // 💰 1. 核心經濟與升級變數
    // ==========================================
    const count = ref(0); // 目前累積的礦石總數（決定柴犬進化）
    const gold = ref(0);  // 玩家的錢包餘額（用來買東西和抽盲盒）
    const clickPower = ref(1); const clickPowerCost = ref(50); // 玩家手動點擊力與升級花費
    const autoClickers = ref(0); const autoClickerCost = ref(100); // 雇傭的小柴犬數量與花費
    const prestigeTokens = ref(0); // 神聖骨頭（轉生代幣）
    const globalMultiplier = ref(1); const multiplierCost = ref(1); // 全域產量倍率與升級花費

    // ==========================================
    // 📈 2. 玩家等級與經驗值系統
    // ==========================================
    const playerName = ref('傳奇柴犬礦工'); const isEditingName = ref(false); 
    const playerExp = ref(0); // 玩家總經驗值
    const totalClicks = ref(0); // 統計總點擊次數（用於解鎖成就）
    
    // 用數學公式計算等級：每級所需的經驗值會越來越多
    const playerLevel = computed(() => Math.floor(Math.sqrt(playerExp.value / 15)) + 1);
    const nextLevelExp = computed(() => Math.pow(playerLevel.value, 2) * 15);
    const expPercent = computed(() => {
      const p = Math.pow(playerLevel.value - 1, 2) * 15;
      return Math.min(((playerExp.value - p) / (nextLevelExp.value - p)) * 100, 100); // 計算經驗條的 % 數
    });

    // 播放音效的快速函數（會檢查玩家是否靜音）
    const playHitSound = () => { if(!isMuted.value) { hitSound.currentTime = 0; hitSound.play().catch(()=>{}); } };
    const playLevelUpSound = () => { if(!isMuted.value) { levelUpSound.currentTime = 0; levelUpSound.play().catch(()=>{}); } };

    // ==========================================
    // 🏆 3. 成就系統 (榮耀牆)
    // ==========================================
    const achievements = ref([
      { id: 1, name: '初出茅廬', desc: '手動點擊 100 次', type: 'clicks', target: 100, done: false },
      { id: 2, name: '柴柴資本家', desc: '累積賺取 1 萬金幣', type: 'gold', target: 10000, done: false },
      { id: 3, name: '黑心犬老闆', desc: '雇傭 30 隻小柴犬', type: 'auto', target: 30, done: false }
    ]);
    // 計算成就加成：每個完成的成就給予 10% (0.1) 的全域加成
    const achievementBonus = computed(() => achievements.value.filter(a => a.done).length * 0.1);

    // 監視器：隨時盯著點擊數、金幣和狗狗數，一達標就自動解鎖成就
    watch([totalClicks, gold, autoClickers], () => {
      achievements.value.forEach(ach => {
        if (!ach.done) {
          if (ach.type === 'clicks' && totalClicks.value >= ach.target) ach.done = true;
          if (ach.type === 'gold' && gold.value >= ach.target) ach.done = true;
          if (ach.type === 'auto' && autoClickers.value >= ach.target) ach.done = true;
          if (ach.done) {
            playLevelUpSound();
            alert(`🏆 解鎖成就：【${ach.name}】！\n全域收益永久獲得 +10% 加成！`);
          }
        }
      });
    });

    // ==========================================
    // 🐕 4. 柴犬進化圖庫 (畫面中間的狗狗圖片)
    // ==========================================
    const levels = [
      { name: '實習挖土小柴', threshold: 0, src: 'https://i.postimg.cc/5jmYLrXG/20231222-131944.webp', class: 'w-48 h-48 rounded-full' },
      { name: '初級礦工犬', threshold: 100, src: 'https://i.postimg.cc/0rCMD4zX/1715850259934.webp', class: 'w-52 h-52 rounded-full' },
      { name: '資深挖掘專家', threshold: 300, src: 'https://i.postimg.cc/SjG2CPng/20200307-103352.webp', class: 'w-56 h-56 rounded-[2rem]' },
      { name: '黃金鑽頭大師', threshold: 600, src: 'https://i.postimg.cc/XXWBZWYt/1578997611541.webp', class: 'w-60 h-60 rounded-[3rem]' },
      { name: '地心守護神柴', threshold: 1000, src: 'https://i.postimg.cc/Cd4Bk2Zy/received-883210349080746.webp', class: 'w-64 h-64 rounded-[4rem]' }
    ];
    // 根據礦石總數(count)自動反推現在是哪個等級
    const currentLevel = computed(() => levels.slice().reverse().find(l => count.value >= l.threshold) || levels[0]);
    const progressPercent = computed(() => Math.min((count.value / 1000) * 100, 100)); // 計算轉生進度條

    // ==========================================
    // 🎰 5. 盲盒裝備抽卡系統
    // ==========================================
    const gachaCost = ref(5000); // 抽一次需要 5000 金幣
    const ownedGears = ref([]);  // 玩家已經抽到的裝備庫存
    const gachaPool = [
      // weight 代表權重 (機率)，bonus 代表產量加成 (0.05 = 5%)
      { name: '生鏽鐵鎬', icon: 'https://i.postimg.cc/3WZ4mqks/Iron-Pickaxe-JE3-BE2.webp', rarity: 'N', weight: 60, bonus: 0.05 },
      { name: '礦工頭盔', icon: 'https://i.postimg.cc/PNMpY7CB/illustration-of-helmet-housing-construction-item-industrial-symbol.webp', rarity: 'N', weight: 60, bonus: 0.05 },
      { name: '鑽石十字鎬', icon: 'https://i.postimg.cc/t7zZWcs8/images.webp', rarity: 'R', weight: 25, bonus: 0.15 },
      { name: '強光探照燈', icon: 'https://i.postimg.cc/9zBRZkD8/20200131165635-999682.webp', rarity: 'R', weight: 25, bonus: 0.15 },
      { name: '黃金礦車', icon: 'https://i.postimg.cc/s1zGBzgH/7DMz-HUQzb1.webp', rarity: 'SR', weight: 8, bonus: 0.50 },
      // 👇 這裡記得檢查是不是你的第12個網址喔！
      { name: '發光晶石', icon: 'https://i.postimg.cc/qNfbPgGY/3372346064d22909dc021a908e8ac767020c7d2c.webp', rarity: 'SR', weight: 8, bonus: 0.50 },
      { name: '神聖柴犬石像', icon: 'https://i.postimg.cc/rzPY9fR5/256px-T-icon-build-Object-Buildable-Goddess-Statue.webp', rarity: 'SSR', weight: 20, bonus: 2.00 }
    ];

    // 把所有抽到的裝備加成總和起來
    const gearBonusMultiplier = computed(() => ownedGears.value.reduce((total, gear) => total + gear.bonus, 0));

    const drawGacha = () => {
      if (gold.value >= gachaCost.value) {
        gold.value -= gachaCost.value; // 扣錢
        // 經典抽卡演算法：計算總權重，然後隨機抽一個
        const totalWeight = gachaPool.reduce((sum, item) => sum + item.weight, 0);
        let randomNum = Math.random() * totalWeight;
        let selectedGear = null;
        for (const item of gachaPool) {
          randomNum -= item.weight;
          if (randomNum <= 0) { selectedGear = { ...item }; break; }
        }
        ownedGears.value.push(selectedGear); playLevelUpSound();
        if (selectedGear.rarity === 'SSR' || selectedGear.rarity === 'SR') {
          alert(`🌟 歐皇降臨！\n恭喜抽中稀有度 ${selectedGear.rarity} 的【${selectedGear.name}】！\n產量額外增加 ${selectedGear.bonus * 100}%！`);
        }
      }
    };

    // ==========================================
    // ⚔️ 6. 巨石挑戰模式
    // ==========================================
    const challenge = ref({ active: false, timeLeft: 0, clicks: 0, target: 100, duration: 15, cooldown: 0, rewardGold: 0, rewardTokens: 0 });
    let challengeTimer = null;

    // 啟動挑戰，設定目標並開始倒數計時
    const startChallenge = (difficulty) => {
      if (challenge.value.cooldown > 0) return;
      if (difficulty === 'easy') { challenge.value.target = 50; challenge.value.duration = 15; challenge.value.rewardGold = 20000; challenge.value.rewardTokens = 1; } 
      else if (difficulty === 'normal') { challenge.value.target = 100; challenge.value.duration = 15; challenge.value.rewardGold = 80000; challenge.value.rewardTokens = 3; } 
      else if (difficulty === 'hard') { challenge.value.target = 160; challenge.value.duration = 15; challenge.value.rewardGold = 300000; challenge.value.rewardTokens = 8; }

      challenge.value.active = true; challenge.value.clicks = 0; challenge.value.timeLeft = challenge.value.duration;
      playLevelUpSound();
      
      const endTime = Date.now() + (challenge.value.duration * 1000);
      if (challengeTimer) clearInterval(challengeTimer);
      
      // 每 0.1 秒更新一次畫面時間，確保時間超精準
      challengeTimer = setInterval(() => {
        const remain = (endTime - Date.now()) / 1000;
        if (remain <= 0) {
          challenge.value.timeLeft = 0;
          endChallenge(false); // 時間到，失敗
        } else {
          challenge.value.timeLeft = remain;
        }
      }, 100); 
    };

    // 挑戰期間的專屬點擊函數
    const clickChallenge = () => {
      if (!challenge.value.active) return;
      challenge.value.clicks++; 
      playHitSound(); 
      if (challenge.value.clicks >= challenge.value.target) endChallenge(true); // 達標，勝利！
    };

    // 挑戰結束處理結算與冷卻
    const endChallenge = (isWin) => {
      if (challengeTimer) clearInterval(challengeTimer);
      challenge.value.active = false; challenge.value.cooldown = 120; // 挑戰結束後進入 120 秒冷卻
      if (isWin) {
        gold.value += challenge.value.rewardGold; prestigeTokens.value += challenge.value.rewardTokens; playerExp.value += 500;
        playLevelUpSound(); alert(`🏆 挑戰成功！\n獲得 ${challenge.value.rewardGold} 金幣與 ${challenge.value.rewardTokens} 根骨頭！`);
      } else { alert(`💀 挑戰失敗...\n巨石太堅硬了，差一點點就打碎了！等冷卻結束再來吧！`); }
    };

    // ==========================================
    // 📊 7. 收益與任務計算系統
    // ==========================================
    // 遊戲最重要的數學公式：計算所有加成後的最終倍率
    const totalMultiplier = computed(() => {
      return globalMultiplier.value * (1 + (playerLevel.value * 0.01) + gearBonusMultiplier.value + achievementBonus.value);
    });

    // 每日任務清單
    const missions = ref([
      { id: 1, title: '手動挖掘', desc: '手動點擊', type: 'clicks', unit: '次', target: 50, reward: 500, level: 1 },
      { id: 2, title: '擴張事業', desc: '雇傭小柴犬', type: 'auto', unit: '隻', target: 5, reward: 2000, level: 1 },
      { id: 3, title: '突破極限', desc: '玩家等級', type: 'level', unit: '級', target: 5, reward: 5000, level: 1 }
    ]);
    const getMissionProgress = (m) => {
      if (m.type === 'clicks') return totalClicks.value;
      if (m.type === 'auto') return autoClickers.value;
      if (m.type === 'level') return playerLevel.value; return 0;
    };
    const isMissionComplete = (m) => getMissionProgress(m) >= m.target;
    
    // 領取任務獎勵，並自動提升下一次任務的難度和獎勵
    const claimMission = (m) => {
      if (isMissionComplete(m)) {
        gold.value += m.reward; playerExp.value += (100 * m.level); playLevelUpSound();
        m.level += 1; m.reward = Math.floor(m.reward * 2.2); 
        if (m.type === 'clicks') m.target += (100 * m.level); 
        if (m.type === 'auto') m.target += 5; 
        if (m.type === 'level') m.target += 5; 
      }
    };

    // ==========================================
    // 🎁 8. 兌換碼系統 (Demo 必備神器)
    // ==========================================
    const giftCodeInput = ref(''); const usedCodes = ref([]);
    // 預設的禮包碼資料庫 (你可以自己新增或修改這裡！)
    const predefinedCodes = {
      // 原本的 3 個
      'ILOVEHACKIT': { gold: 500000, exp: 5000, msg: '🔥 黑客松魂爆發！獲得 50 萬金幣與 5000 經驗值！' },
      'TEAMHUNG': { tokens: 20, clickPower: 100, msg: '🎉 Team Hung 專屬福利！獲得 20 根神聖骨頭與 +100 點擊力！' },
      'TEAMLA': { gold: 999999, exp: 9999, msg: '🚀 Team La 降臨！獲得 99 萬金幣，直接財富自由！' },
      
      // 新增的 3 個
      'ENIC0205': { gold: 205000, exp: 2050, msg: '🎂 專屬密碼 ENIC0205 啟動！獲得 20.5 萬金幣與 2050 經驗值！' },
      'GUACC': { clickPower: 88, msg: '🥑 GUACC 能量注入！永久點擊力暴增 +88！' },
      'TAYLORPEW': { tokens: 50, gold: 1000000, msg: '✨ TAYLORPEW 閃耀登場！獲得 50 根神聖骨頭與 100 萬金幣！' }
    };
    const redeemCode = () => {
      const code = giftCodeInput.value.trim().toUpperCase(); if (!code) return;
      if (usedCodes.value.includes(code)) { alert('❌ 已兌換過！'); return; }
      const r = predefinedCodes[code];
      if (r) {
        if (r.gold) gold.value += r.gold; if (r.exp) playerExp.value += r.exp;
        if (r.tokens) prestigeTokens.value += r.tokens; if (r.clickPower) clickPower.value += r.clickPower;
        usedCodes.value.push(code); giftCodeInput.value = ''; playLevelUpSound();
        alert(`🎁 兌換成功！\n${r.msg}`);
      } else { alert('❌ 禮包碼錯誤！'); }
    };

    // ==========================================
    // ⚡ 9. 技能系統與核心點擊邏輯
    // ==========================================
    const skill1CD = ref(0); const skill2CD = ref(0); const isFrenzy = ref(false); // CD與狂暴狀態
    const formatTime = (sec) => {
      if (sec <= 0) return "準備就緒"; return `${Math.floor(sec / 60)}:${(sec % 60).toString().padStart(2, '0')}`;
    };

    const isMuted = ref(false); let bgmStarted = false; let particles = [];
    const toggleMute = () => {
      isMuted.value = !isMuted.value; bgm.muted = isMuted.value;
      if (!isMuted.value && !bgmStarted) { bgm.play().then(()=>bgmStarted=true).catch(()=>{}); }
    };

    // 產生飄浮數字特效
    const spawnParticle = (x, y, text) => { 
      if (particles.length > 25) particles.shift(); // 限制畫面上最多25個特效防卡頓
      particles.push({ x: x + (Math.random()*50-25), y, text, alpha: 1, scale: 1, speed: 3 + Math.random()*2 }); 
    };

    // 技能 1：直接獲得 300 秒的自動產量
    const useSkill1 = () => {
      if (skill1CD.value > 0) return;
      const r = Math.floor(autoClickers.value * totalMultiplier.value * 300);
      if(r===0) { alert("⚠️ 需先雇傭柴犬！"); return; }
      count.value+=r; gold.value+=r; playerExp.value+=50; skill1CD.value=180; 
      spawnParticle(window.innerWidth/2, window.innerHeight/2, `💥 +${r}`); playLevelUpSound();
    };
    
    // 技能 2：進入 10 秒狂暴狀態
    const useSkill2 = () => {
      if (skill2CD.value > 0) return;
      isFrenzy.value = true; skill2CD.value = 300; playLevelUpSound();
      setTimeout(() => { isFrenzy.value = false; }, 10000); // 10秒後解除狂暴
    };

    // 最核心的：當你點擊那隻柴犬時發生的事！
    const handleClick = (event) => {
      if (challenge.value.active) return; // 如果在挑戰模式中，點擊柴犬無效
      if (!bgmStarted && !isMuted.value) { bgm.play().then(()=>bgmStarted=true).catch(()=>{}); } // 啟動背景音樂
      totalClicks.value++; playerExp.value++; 
      
      // 根據點擊力與總倍率計算獲得數量
      const gained = Math.floor(clickPower.value * totalMultiplier.value);
      count.value += gained; gold.value += gained;
      spawnParticle(event.clientX, event.clientY, `+${gained}`); playHitSound();
    };

    const buyClickPower = () => {
      if (gold.value >= clickPowerCost.value) { gold.value -= clickPowerCost.value; clickPower.value++; playerExp.value+=5; clickPowerCost.value = Math.floor(clickPowerCost.value * 1.5); }
    };
    const buyAutoClicker = () => {
      if (gold.value >= autoClickerCost.value) { gold.value -= autoClickerCost.value; autoClickers.value++; playerExp.value+=10; autoClickerCost.value = Math.floor(autoClickerCost.value * 1.5); }
    };

    // 轉生機制：重置進度換取代幣
    const prestige = () => {
      if (count.value >= 1000) {
        const t = Math.floor(count.value / 1000); prestigeTokens.value += t;
        const b = t * 100000; count.value = 0; gold.value = b; 
        clickPower.value = 1; clickPowerCost.value = 50; autoClickers.value = 0; autoClickerCost.value = 100; playerExp.value += 500; 
        alert(`🌋 挖穿地心！\n獲得 ${t} 根神聖骨頭與 ${b} 金幣！`);
      }
    };
    const buyMultiplier = () => {
      if (prestigeTokens.value >= multiplierCost.value) { prestigeTokens.value -= multiplierCost.value; globalMultiplier.value++; multiplierCost.value++; }
    };

    // ==========================================
    // 💾 10. 存檔與讀檔系統
    // ==========================================
    const saveGame = (slot) => {
      const saveData = {
        playerName: playerName.value, playerExp: playerExp.value, count: count.value, gold: gold.value, clickPower: clickPower.value, clickPowerCost: clickPowerCost.value,
        autoClickers: autoClickers.value, autoClickerCost: autoClickerCost.value, prestigeTokens: prestigeTokens.value, globalMultiplier: globalMultiplier.value, multiplierCost: multiplierCost.value,
        lastSaveTime: Date.now(), totalClicks: totalClicks.value, missionsData: missions.value.map(m => ({ level: m.level, target: m.target, reward: m.reward })), usedCodes: usedCodes.value, ownedGears: ownedGears.value,
        achievementsDone: achievements.value.map(a => a.done)
      };
      localStorage.setItem(`shiba_rpg_v9_save_${slot}`, JSON.stringify(saveData)); alert(`✅ 寫入 [卷宗 ${slot}]`);
    };

    const loadGame = (slot) => {
      const str = localStorage.getItem(`shiba_rpg_v9_save_${slot}`);
      if (str) {
        const d = JSON.parse(str);
        // 讀取所有資料，如果沒有就給預設值
        playerName.value = d.playerName || '傳奇柴犬礦工'; playerExp.value = d.playerExp || 0;
        count.value = d.count||0; gold.value = d.gold||0; clickPower.value = d.clickPower||1; clickPowerCost.value = d.clickPowerCost||50;
        autoClickers.value = d.autoClickers||0; autoClickerCost.value = d.autoClickerCost||100;
        prestigeTokens.value = d.prestigeTokens||0; globalMultiplier.value = d.globalMultiplier||1; multiplierCost.value = d.multiplierCost||1;
        totalClicks.value = d.totalClicks || 0;
        if (d.missionsData) d.missionsData.forEach((m, i) => { if(missions.value[i]){ missions.value[i].level = m.level; missions.value[i].target = m.target; missions.value[i].reward = m.reward; }});
        usedCodes.value = d.usedCodes || []; ownedGears.value = d.ownedGears || [];
        if (d.achievementsDone) d.achievementsDone.forEach((done, i) => { if(achievements.value[i]) achievements.value[i].done = done; }); 

        // 🌟 離線收益計算 (Demo神技：這裡改成 5 秒就能觸發！)
        if (d.lastSaveTime && autoClickers.value > 0) {
          const diffSec = Math.floor((Date.now() - d.lastSaveTime) / 1000);
          if (diffSec > 5) { // 👈 就是這裡！大於 5 秒就會給你離線收益
            const off = Math.floor(diffSec * autoClickers.value * totalMultiplier.value); count.value += off; gold.value += off;
            alert(`💤 歡迎回來，${playerName.value}！\n離線期間挖出了 ${off} 礦石與金幣！`); return;
          }
        }
        alert(`📂 已載入 [卷宗 ${slot}]`);
      } else { alert(`⚠️ [卷宗 ${slot}] 是空的！`); }
    };

    // ==========================================
    // ✨ 11. 畫面 Canvas 動態特效渲染
    // ==========================================
    const canvasRef = ref(null); let ctx = null;
    const initCanvas = () => { canvasRef.value.width = window.innerWidth; canvasRef.value.height = window.innerHeight; ctx = canvasRef.value.getContext('2d'); requestAnimationFrame(animateParticles); };
    const animateParticles = () => {
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      particles.forEach(p => {
        p.y -= p.speed; p.alpha -= 0.015; p.scale += 0.005; ctx.save(); ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.font = `900 ${45*p.scale}px 'Arial Black', sans-serif`; ctx.fillStyle = '#FFE600'; ctx.strokeStyle = '#000000';
        ctx.lineWidth = 6; ctx.shadowColor = 'rgba(0,0,0,0.9)'; ctx.shadowBlur = 10; ctx.translate(p.x, p.y); ctx.strokeText(p.text, 0, 0); ctx.fillText(p.text, 0, 0); ctx.restore();
      });
      particles = particles.filter(p => p.alpha > 0); requestAnimationFrame(animateParticles); // 清除透明度低於0的數字
    };

    // ==========================================
    // ⏱️ 12. 遊戲主迴圈 (每秒自動執行的事情)
    // ==========================================
    onMounted(() => {
      initCanvas(); window.addEventListener('resize', () => { if(canvasRef.value){ canvasRef.value.width = window.innerWidth; canvasRef.value.height = window.innerHeight; }});
      
      setInterval(() => {
        // 1. 扣除技能冷卻時間
        if (skill1CD.value > 0) skill1CD.value--; if (skill2CD.value > 0) skill2CD.value--;
        if (challenge.value.cooldown > 0 && !challenge.value.active) challenge.value.cooldown--;

        // 2. 處理狂暴狀態下的被動收益
        if (isFrenzy.value) {
           const f = Math.floor(clickPower.value * totalMultiplier.value * 15); count.value += f; gold.value += f; playerExp.value += 5; 
           const img = document.querySelector('img.object-cover'); if(img) spawnParticle(img.getBoundingClientRect().left + img.getBoundingClientRect().width/2, img.getBoundingClientRect().top + img.getBoundingClientRect().height/2, `🔥 +${f}`);
        }
        
        // 3. 處理小柴犬的自動掛機收益
        if (autoClickers.value > 0) {
          const g = Math.floor(autoClickers.value * totalMultiplier.value); count.value += g; gold.value += g; playerExp.value += (autoClickers.value * 0.1); 
          const img = document.querySelector('img.object-cover'); if(img && !isFrenzy.value && !challenge.value.active) spawnParticle(img.getBoundingClientRect().left + img.getBoundingClientRect().width/2, img.getBoundingClientRect().top + img.getBoundingClientRect().height/2, `+${g}`);
        }
      }, 1000); // 1000 毫秒 = 1 秒
    });

    // 必須把變數丟出來，HTML 面板才能讀取到它們
    return { 
      count, gold, currentLevel, handleClick, canvasRef, clickPower, clickPowerCost, buyClickPower, autoClickers, autoClickerCost, buyAutoClicker,
      prestige, prestigeTokens, globalMultiplier, multiplierCost, buyMultiplier, progressPercent, saveGame, loadGame, isMuted, toggleMute, totalMultiplier,
      skill1CD, skill2CD, isFrenzy, useSkill1, useSkill2, formatTime, playerName, isEditingName, playerExp, playerLevel, nextLevelExp, expPercent,
      missions, claimMission, isMissionComplete, getMissionProgress, giftCodeInput, redeemCode, gachaCost, ownedGears, drawGacha, gearBonusMultiplier,
      challenge, startChallenge, clickChallenge, achievements, achievementBonus 
    };
  }
}).mount('#app');